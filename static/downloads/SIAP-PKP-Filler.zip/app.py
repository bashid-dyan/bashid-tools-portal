"""
SIAP PKP Filler — Flask Web App
"""

import os
import uuid
import json
import threading
from flask import Flask, request, jsonify, Response, render_template
from werkzeug.utils import secure_filename
from siap_filler import (
    read_excel, get_sheet_names, load_auth, match_prosedurs,
    detect_auditor, run_filler
)

app = Flask(__name__, static_folder='static', static_url_path='/static')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

jobs = {}


def process_job(job_id):
    """Background worker."""
    try:
        job = jobs[job_id]
        job['status'] = 'processing'

        auth_info = load_auth(job['auth_data'])
        prosedur_list = job['prosedur_data']
        excel_data = read_excel(job['excel_path'], job['sheet_name'], job['excel_config'])

        # Detect auditor if not provided
        auditor = job.get('auditor_info')
        if not auditor or not auditor.get('nip'):
            auditor = detect_auditor(auth_info, prosedur_list)
            if not auditor or auditor.get('error'):
                err_detail = auditor.get('error', 'Unknown') if auditor else 'No result'
                job['status'] = 'error'
                job['error'] = f'Auto-detect auditor gagal ({err_detail}). Isi NIP dan Nama Auditor di form lalu coba lagi.'
                return

        # Match
        submissions, skipped = match_prosedurs(prosedur_list, excel_data)
        job['skipped'] = skipped
        job['total_prosedur'] = len(prosedur_list)
        job['total_excel'] = len(excel_data)
        job['total_matched'] = len(submissions)

        if not submissions:
            job['status'] = 'error'
            job['error'] = 'Tidak ada data yang bisa disubmit. Pastikan nomor prosedur di Excel cocok.'
            return

        job['auditor_info'] = auditor

        def on_progress(current, total, no, status_text):
            jobs[job_id]['current'] = current
            jobs[job_id]['total'] = total
            jobs[job_id]['logs'].append({
                'index': current, 'total': total,
                'no': no, 'status': status_text
            })
            if len(jobs[job_id]['logs']) > 300:
                jobs[job_id]['logs'] = jobs[job_id]['logs'][-300:]

        summary = run_filler(
            auth_info, prosedur_list, submissions, auditor,
            dry_run=job.get('dry_run', False),
            on_progress=on_progress
        )

        job['status'] = 'done'
        job['summary'] = summary
        job['summary']['skipped'] = len(skipped)

    except Exception as e:
        jobs[job_id]['status'] = 'error'
        jobs[job_id]['error'] = str(e)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    # Validate files
    if 'excel' not in request.files:
        return jsonify({'error': 'File Excel tidak ada'}), 400
    if 'auth' not in request.files:
        return jsonify({'error': 'File auth.json tidak ada'}), 400
    if 'prosedur' not in request.files:
        return jsonify({'error': 'File prosedur_list.json tidak ada'}), 400

    excel_file = request.files['excel']
    auth_file = request.files['auth']
    prosedur_file = request.files['prosedur']

    if not excel_file.filename.lower().endswith('.xlsx'):
        return jsonify({'error': 'File Excel harus .xlsx'}), 400

    job_id = str(uuid.uuid4())[:8]

    # Save Excel
    excel_path = os.path.join(UPLOAD_DIR, f"{job_id}_{secure_filename(excel_file.filename)}")
    excel_file.save(excel_path)

    # Parse JSON files
    try:
        auth_data = json.load(auth_file)
    except Exception:
        return jsonify({'error': 'auth.json tidak valid'}), 400

    try:
        prosedur_data = json.load(prosedur_file)
    except Exception:
        return jsonify({'error': 'prosedur_list.json tidak valid'}), 400

    # Get form data
    sheet_name = request.form.get('sheet', '')
    dry_run = request.form.get('dry_run') == 'true'
    nip = request.form.get('nip', '').strip()
    nama = request.form.get('nama', '').strip()

    if not sheet_name:
        return jsonify({'error': 'Nama sheet harus diisi'}), 400

    excel_config = {
        "header_row": int(request.form.get('header_row', 16)),
        "data_start_row": int(request.form.get('data_start_row', 19)),
        "no_col": int(request.form.get('no_col', 1)),
        "hasil_col": int(request.form.get('hasil_col', 7)),
        "langkah_col": int(request.form.get('langkah_col', 2)),
    }

    auditor_info = None
    if nip and nama:
        auditor_info = {
            "nip": nip, "nama": nama,
            "peran": request.form.get('peran', 'Anggota Tim'),
            "peranLvl": request.form.get('peran_lvl', '6'),
        }

    jobs[job_id] = {
        'status': 'queued',
        'current': 0, 'total': 0,
        'logs': [],
        'summary': None, 'error': None,
        'excel_path': excel_path,
        'sheet_name': sheet_name,
        'excel_config': excel_config,
        'auth_data': auth_data,
        'prosedur_data': prosedur_data,
        'auditor_info': auditor_info,
        'dry_run': dry_run,
        'skipped': [],
    }

    thread = threading.Thread(target=process_job, args=(job_id,), daemon=True)
    thread.start()

    return jsonify({'job_id': job_id})


@app.route('/sheets', methods=['POST'])
def sheets():
    """Get sheet names from uploaded Excel."""
    if 'excel' not in request.files:
        return jsonify({'error': 'No file'}), 400
    f = request.files['excel']
    tmp_path = os.path.join(UPLOAD_DIR, f"tmp_{secure_filename(f.filename)}")
    f.save(tmp_path)
    try:
        names = get_sheet_names(tmp_path)
        return jsonify({'sheets': names})
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    finally:
        os.remove(tmp_path)


@app.route('/progress/<job_id>')
def progress(job_id):
    def generate():
        import time as _time
        retries = 0
        while job_id not in jobs and retries < 10:
            _time.sleep(0.5)
            retries += 1
        if job_id not in jobs:
            yield f"data: {json.dumps({'error': 'Job tidak ditemukan'})}\n\n"
            return
        last_sent = 0
        while True:
            job = jobs.get(job_id)
            if not job:
                yield f"data: {json.dumps({'error': 'Job tidak ditemukan'})}\n\n"
                break

            logs_to_send = job['logs'][last_sent:]
            last_sent = len(job['logs'])

            payload = {
                'status': job['status'],
                'current': job['current'],
                'total': job['total'],
                'logs': logs_to_send,
            }

            if job['status'] == 'done':
                payload['summary'] = job['summary']
                payload['auditor'] = job.get('auditor_info', {})
                payload['total_prosedur'] = job.get('total_prosedur', 0)
                payload['total_excel'] = job.get('total_excel', 0)
                payload['total_matched'] = job.get('total_matched', 0)
                yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
                break
            elif job['status'] == 'error':
                payload['error'] = job['error']
                yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
                break

            yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
            import time
            time.sleep(1)

    return Response(generate(), mimetype='text/event-stream',
                    headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=False)
