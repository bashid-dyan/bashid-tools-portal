"""
SIAP BPK - PKP Auto Filler — Web Version
Refactored dari siap_pkp_filler.py untuk dipakai di Flask web app.
"""

import json
import sys
import os
import ssl
import time
import urllib.request
import urllib.parse
from collections import defaultdict
from datetime import datetime


def read_excel(filepath, sheet_name, config):
    """Baca file Excel dan return list of {no, hasil, langkah}."""
    import openpyxl
    wb = openpyxl.load_workbook(filepath, data_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(f"Sheet '{sheet_name}' tidak ditemukan. Sheet yang ada: {wb.sheetnames}")

    ws = wb[sheet_name]
    langkah_col = config.get("langkah_col", 2)
    results = []
    for row_idx in range(config["data_start_row"], ws.max_row + 1):
        no = ws.cell(row=row_idx, column=config["no_col"]).value
        hasil = ws.cell(row=row_idx, column=config["hasil_col"]).value
        langkah = ws.cell(row=row_idx, column=langkah_col).value
        if no is not None:
            no_str = str(no).strip()
            hasil_str = str(hasil).strip() if hasil is not None else ""
            langkah_str = str(langkah).strip() if langkah is not None else ""
            results.append({"no": no_str, "hasil": hasil_str, "langkah": langkah_str})

    b_results = [r for r in results if r["no"].startswith("B.") and r["hasil"]]
    return b_results


def get_sheet_names(filepath):
    """Get list of sheet names from Excel file."""
    import openpyxl
    wb = openpyxl.load_workbook(filepath, read_only=True)
    return wb.sheetnames


def load_auth(auth_data):
    """Load auth tokens dari dict/JSON."""
    if isinstance(auth_data, str):
        auth = json.loads(auth_data)
    else:
        auth = auth_data

    cookie_dict = {}
    for c in auth["cookies"].split(";"):
        c = c.strip()
        if "=" in c:
            k, v = c.split("=", 1)
            cookie_dict[k.strip()] = v.strip()

    xsrf = urllib.parse.unquote(cookie_dict.get("XSRF-TOKEN", ""))
    return {"xsrf": xsrf, "idp": auth["idp"], "cookies": auth["cookies"]}


def api_post(url, payload, auth_info):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Bearer " + auth_info["idp"],
        "X-XSRF-TOKEN": auth_info["xsrf"],
        "Cookie": auth_info["cookies"],
    })
    resp = urllib.request.urlopen(req, context=ctx)
    return json.loads(resp.read())


def api_get(url, auth_info):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "Authorization": "Bearer " + auth_info["idp"],
        "X-XSRF-TOKEN": auth_info["xsrf"],
        "Cookie": auth_info["cookies"],
    })
    resp = urllib.request.urlopen(req, context=ctx)
    return json.loads(resp.read())


def detect_auditor(auth_info, prosedur_list):
    """Auto-detect auditor info dari prosedur detail. Coba beberapa prosedur."""
    if not prosedur_list:
        return {"error": "prosedur_list kosong"}

    last_error = None
    # Coba hingga 3 prosedur pertama
    for item in prosedur_list[:3]:
        try:
            pid = item["id"]
            detail = api_get(
                f"https://siap.bpk.go.id/api/subpemeriksaan/prosedur/detail/{pid}",
                auth_info
            )
            if detail.get("success") and detail.get("data", {}).get("Pic"):
                pics = detail["data"]["Pic"]
                if pics:
                    pic = pics[0]
                    return {
                        "nip": pic.get("NIP", ""),
                        "nama": pic.get("Nama", ""),
                        "peran": pic.get("Peran", "Anggota Tim"),
                        "peranLvl": pic.get("PeranLvl", "6"),
                    }
            # Jika success tapi tidak ada Pic, coba prosedur berikutnya
            last_error = f"Prosedur {pid}: success tapi Pic kosong. Response keys: {list(detail.get('data', {}).keys())}"
        except Exception as e:
            last_error = f"Prosedur {item.get('id','?')}: {str(e)}"

    return {"error": f"Auto-detect gagal: {last_error}"}


def _text_similarity(a, b):
    if not a or not b:
        return 0.0
    a_lower = a.lower().strip()
    b_lower = b.lower().strip()
    if a_lower == b_lower:
        return 1.0
    a_prefix = a_lower[:80]
    b_prefix = b_lower[:80]
    if a_prefix == b_prefix:
        return 0.95
    a_words = set(a_lower.split())
    b_words = set(b_lower.split())
    if not a_words or not b_words:
        return 0.0
    overlap = len(a_words & b_words)
    return overlap / max(len(a_words), len(b_words))


def match_prosedurs(website_prosedurs, excel_data):
    excel_by_no = defaultdict(list)
    for d in excel_data:
        excel_by_no[d["no"]].append(d)

    used_excel = set()
    submissions = []
    skipped = []

    for item in website_prosedurs:
        no = item["no"]
        web_nama = item.get("nama", "")

        if no not in excel_by_no:
            skipped.append({"no": no, "reason": "Tidak ada di Excel"})
            continue

        candidates = excel_by_no[no]
        available = [(i, c) for i, c in enumerate(candidates) if (no, i) not in used_excel]

        if not available:
            skipped.append({"no": no, "reason": "Semua kemunculan sudah terpakai"})
            continue

        if len(available) == 1:
            idx, best = available[0]
        elif web_nama:
            scored = []
            for idx, cand in available:
                sim = _text_similarity(web_nama, cand.get("langkah", ""))
                scored.append((sim, idx, cand))
            scored.sort(key=lambda x: -x[0])
            best_sim, idx, best = scored[0]
            if best_sim < 0.1:
                idx, best = available[0]
        else:
            idx, best = available[0]

        used_excel.add((no, idx))
        hasil = best["hasil"]
        if hasil and len(hasil.strip()) > 0:
            submissions.append({"id": item["id"], "no": no, "hasil": hasil.strip()})
        else:
            skipped.append({"no": no, "reason": "Hasil kosong"})

    return submissions, skipped


def pad_short_text(text, min_length=101):
    if len(text) >= min_length:
        return text
    padding = " Hasil pengujian telah didokumentasikan dalam kertas kerja pemeriksaan sesuai prosedur yang ditetapkan."
    return text + padding


def run_filler(auth_info, prosedur_list, submissions, auditor_info, dry_run=False, on_progress=None):
    """Submit semua hasil pengujian ke SIAP BPK dengan callback progress."""
    BASE = "https://siap.bpk.go.id"
    total = len(submissions)
    success = 0
    failed = 0
    errors = []

    for i, sub in enumerate(submissions):
        try:
            url = f"{BASE}/api/subpemeriksaan/prosedur/store/{sub['id']}"
            hasil_text = pad_short_text(sub["hasil"])

            payload = {
                "hasilPengujian": "<p>" + hasil_text + "</p>",
                "nip": auditor_info["nip"],
                "nama": auditor_info["nama"],
                "peran": auditor_info["peran"],
                "peranLvl": auditor_info["peranLvl"],
                "nip2": False,
            }

            if dry_run:
                success += 1
                status_text = f"DRY-RUN OK ({len(hasil_text)} chars)"
            else:
                result = api_post(url, payload, auth_info)
                if result.get("success"):
                    success += 1
                    status_text = "OK"
                else:
                    msg = result.get("error", {}).get("message", str(result))
                    failed += 1
                    errors.append({"no": sub["no"], "error": msg})
                    status_text = f"GAGAL: {msg}"

            if on_progress:
                on_progress(i + 1, total, sub["no"], status_text)

            if not dry_run and (i + 1) % 10 == 0:
                time.sleep(1)

        except Exception as e:
            failed += 1
            errors.append({"no": sub["no"], "error": str(e)})
            if on_progress:
                on_progress(i + 1, total, sub["no"], f"ERROR: {e}")

    return {"success": success, "failed": failed, "errors": errors, "total": total}
