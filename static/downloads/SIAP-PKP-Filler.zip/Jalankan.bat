@echo off
echo ============================================
echo   SIAP PKP Filler - Web App (Lokal)
echo ============================================
echo.
echo Pastikan VPN BPK sudah terhubung!
echo.
echo Buka browser dan akses:
echo   http://localhost:5001
echo.
echo Jangan tutup jendela ini selama menggunakan tools.
echo ============================================
echo.
python app.py
pause
