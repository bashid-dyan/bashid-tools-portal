/**
 * SIAP BPK - Export Auth & Prosedur List
 * =======================================
 *
 * CARA PAKAI:
 * 1. Login ke SIAP BPK (https://siap.bpk.go.id)
 * 2. Buka halaman Prosedur PKP yang ingin diisi
 *    (Menu: Pelaksanaan > Prosedur)
 * 3. Tekan F12, klik tab "Console"
 * 4. Copy-paste SELURUH isi file ini ke Console
 * 5. Tekan Enter
 * 6. Tunggu sampai muncul notifikasi "SELESAI"
 * 7. Dua file akan terdownload:
 *    - auth.json (token autentikasi)
 *    - prosedur_list.json (daftar prosedur & ID)
 * 8. Pindahkan kedua file ke folder Downloads (biasanya sudah di sana)
 *
 * CATATAN:
 * - Pastikan Anda sudah di halaman PROSEDUR (bukan halaman lain)
 * - Jika ada filter aktif (PKP Saya, dll), hapus filter dulu
 *   agar semua prosedur tampil
 * - Script akan mengambil data via API (lebih cepat, termasuk nama prosedur)
 */

(async function() {
    console.log('=== SIAP PKP EXPORTER ===');
    console.log('Mulai export data...');

    // ---- 1. EXPORT AUTH ----
    console.log('[1/3] Mengambil auth tokens...');
    const idpToken = localStorage.getItem('idp_token');
    const cookies = document.cookie;

    if (!idpToken) {
        console.error('ERROR: idp_token tidak ditemukan. Pastikan Anda sudah login!');
        return;
    }

    const authData = JSON.stringify({ idp: idpToken, cookies: cookies });
    const authBlob = new Blob([authData], { type: 'application/json' });
    const authUrl = URL.createObjectURL(authBlob);
    const authLink = document.createElement('a');
    authLink.href = authUrl;
    authLink.download = 'auth.json';
    authLink.click();
    console.log('[1/3] auth.json berhasil didownload');

    // ---- 2. KUMPULKAN SEMUA PROSEDUR VIA API ----
    console.log('[2/3] Mengumpulkan data prosedur via API...');

    // Cek apakah kita di halaman prosedur dan extract subpemeriksaan ID
    if (!window.location.href.includes('/pelaksanaan/prosedur')) {
        console.error('ERROR: Anda harus berada di halaman Prosedur!');
        console.error('Navigasi ke: Pelaksanaan > Prosedur');
        return;
    }

    const urlParts = window.location.href.match(/subpemeriksaan\/([a-f0-9-]+)\//);
    if (!urlParts) {
        console.error('ERROR: Tidak bisa mendeteksi ID subpemeriksaan dari URL');
        return;
    }
    const subId = urlParts[1];
    console.log('  Subpemeriksaan ID: ' + subId);

    // Fetch prosedur data via API
    let allItems = [];
    try {
        const resp = await fetch(`/api/subpemeriksaan/prosedur/bundle/data/${subId}`, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + idpToken
            }
        });
        const data = await resp.json();

        if (!data.success || !data.data) {
            console.error('ERROR: API gagal:', data.error || 'Unknown error');
            console.log('Fallback ke scraping DOM...');
            // Fallback ke scraping jika API gagal
            allItems = await fallbackScrape();
        } else {
            // Sort by NoUrut dan map ke format {no, id, nama}
            const sorted = data.data.sort((a, b) => a.NoUrut - b.NoUrut);
            allItems = sorted.map(d => ({
                no: d.Kode,
                id: d.Id,
                nama: d.Nama || ''
            }));
            console.log(`[2/3] Total prosedur dari API: ${allItems.length}`);
        }
    } catch (e) {
        console.error('ERROR fetch API:', e.message);
        console.log('Fallback ke scraping DOM...');
        allItems = await fallbackScrape();
    }

    // Fallback: scrape DOM jika API gagal
    async function fallbackScrape() {
        function scrapeCurrentPage() {
            const rows = document.querySelectorAll('[role="row"]');
            const items = [];
            rows.forEach(row => {
                const badge = row.querySelector('.rounded-pill, .badge');
                const link = row.querySelector('a[href*="/pelaksanaan/prosedur/"]');
                if (badge && link) {
                    const no = badge.textContent.trim();
                    const id = link.getAttribute('href').split('/').pop();
                    items.push({ no, id, nama: '' });
                }
            });
            return items;
        }

        // Ubah page size ke 100
        const allBtns = document.querySelectorAll('button');
        for (const btn of allBtns) {
            if (btn.textContent.trim() === '100') {
                btn.click();
                await new Promise(r => setTimeout(r, 3000));
                console.log('  Page size diubah ke 100');
                break;
            }
        }

        let items = [];
        let pageNum = 1;
        const maxPages = 20;

        while (pageNum <= maxPages) {
            const pageItems = scrapeCurrentPage();
            const newItems = pageItems.filter(item => !items.find(x => x.id === item.id));
            items.push(...newItems);
            console.log(`  Halaman ${pageNum}: +${newItems.length} prosedur (total: ${items.length})`);

            const pageButtons = document.querySelectorAll('.page-link, [aria-label^="Page "]');
            let nextPage = null;
            pageButtons.forEach(b => {
                if (b.getAttribute('aria-label') === `Page ${pageNum + 1}` || b.textContent.trim() === String(pageNum + 1)) {
                    nextPage = b;
                }
            });

            if (!nextPage || newItems.length === 0) break;
            nextPage.click();
            await new Promise(r => setTimeout(r, 2000));
            pageNum++;
        }
        return items;
    }

    // ---- 3. DOWNLOAD PROSEDUR LIST ----
    console.log('[3/3] Mendownload prosedur_list.json...');
    const prosedurData = JSON.stringify(allItems, null, 2);
    const prosedurBlob = new Blob([prosedurData], { type: 'application/json' });
    const prosedurUrl = URL.createObjectURL(prosedurBlob);
    const prosedurLink = document.createElement('a');
    prosedurLink.href = prosedurUrl;
    prosedurLink.download = 'prosedur_list.json';
    prosedurLink.click();

    console.log('');
    console.log('=== SELESAI ===');
    console.log(`Total prosedur: ${allItems.length}`);
    console.log('');
    console.log('File yang didownload:');
    console.log('  1. auth.json - Token autentikasi');
    console.log('  2. prosedur_list.json - Daftar prosedur (termasuk nama/isi prosedur)');
    console.log('');
    console.log('Selanjutnya jalankan:');
    console.log('  python siap_pkp_filler.py --excel "path/file.xlsx" --sheet "NAMA_SHEET"');

})();
