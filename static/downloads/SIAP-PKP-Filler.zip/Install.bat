@echo off
echo ============================================
echo   SIAP PKP Filler - Install Dependencies
echo ============================================
echo.
pip install flask openpyxl
echo.
echo Selesai! Sekarang klik "Jalankan.bat"
pause
