@echo off
echo ============================================
echo   SPSE Checker - Web App (Lokal)
echo ============================================
echo.
echo Buka browser dan akses:
echo   http://localhost:5000
echo.
echo Jangan tutup jendela ini selama menggunakan tools.
echo ============================================
echo.
python app.py
pause
