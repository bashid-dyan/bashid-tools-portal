@echo off
echo ============================================
echo   SPSE Checker - Install Dependencies
echo ============================================
echo.
pip install flask requests
echo.
echo Selesai! Sekarang klik "Jalankan.bat"
pause
