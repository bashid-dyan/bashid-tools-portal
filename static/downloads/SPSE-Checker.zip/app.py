"""
SPSE Checker — Flask Web App
Cek data pengadaan barang/jasa pemerintah dari SPSE/LPSE
"""

import os
import json
import atexit
from flask import Flask, request, jsonify, render_template
import spse_client

app = Flask(__name__, static_folder='static', static_url_path='/static')

COMMON_LPSE = [
    {"code": "pu", "nama": "Kementerian PUPR"},
    {"code": "kemenkeu", "nama": "Kementerian Keuangan"},
    {"code": "lkpp", "nama": "LKPP"},
    {"code": "kemhan", "nama": "Kementerian Pertahanan"},
    {"code": "kemendikbud", "nama": "Kemendikbudristek"},
    {"code": "kemenkes", "nama": "Kementerian Kesehatan"},
    {"code": "kemenag", "nama": "Kementerian Agama"},
    {"code": "kemenhub", "nama": "Kementerian Perhubungan"},
    {"code": "kemensos", "nama": "Kementerian Sosial"},
    {"code": "kemenperin", "nama": "Kementerian Perindustrian"},
    {"code": "jakarta", "nama": "Prov. DKI Jakarta"},
    {"code": "jawabarat", "nama": "Prov. Jawa Barat"},
    {"code": "jateng", "nama": "Prov. Jawa Tengah"},
    {"code": "jatim", "nama": "Prov. Jawa Timur"},
    {"code": "sumut", "nama": "Prov. Sumatera Utara"},
    {"code": "sulsel", "nama": "Prov. Sulawesi Selatan"},
    {"code": "sulteng", "nama": "Prov. Sulawesi Tengah"},
    {"code": "kaltim", "nama": "Prov. Kalimantan Timur"},
    {"code": "bali", "nama": "Prov. Bali"},
    {"code": "papua", "nama": "Prov. Papua"},
]


@app.route('/')
def index():
    return render_template('index.html', lpse_list=COMMON_LPSE)


@app.route('/api/search')
def api_search():
    instansi = request.args.get('instansi', '').strip()
    keyword = request.args.get('q', '').strip()
    jenis = request.args.get('jenis', 'tender')  # tender or non_tender
    tahun = request.args.get('tahun', '').strip()
    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 20))

    if not instansi:
        return jsonify({'error': 'Pilih instansi LPSE'}), 400

    try:
        if jenis == 'non_tender':
            data = spse_client.search_non_tender(instansi, keyword, tahun, start, length)
        else:
            data = spse_client.search_tender(instansi, keyword, tahun, start, length)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/detail')
def api_detail():
    instansi = request.args.get('instansi', '').strip()
    paket_id = request.args.get('id', '').strip()
    jenis = request.args.get('jenis', 'tender')

    if not instansi or not paket_id:
        return jsonify({'error': 'Parameter instansi dan id harus diisi'}), 400

    try:
        if jenis == 'non_tender':
            data = spse_client.get_detail_non_tender(instansi, paket_id)
        else:
            data = spse_client.get_detail_tender(instansi, paket_id)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


atexit.register(spse_client.close)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
