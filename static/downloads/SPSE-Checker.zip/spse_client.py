"""
SPSE Client — Wrapper untuk akses data pengadaan dari SPSE/LPSE
Mengakses data publik tanpa autentikasi khusus.
"""

import requests
import re
import time

BASE_INAPROC = "https://spse.inaproc.id"
LPSE_LIST_URL = "https://satudata.inaproc.id/service/daftarLPSE"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'application/json, text/html',
}

_session = requests.Session()
_session.headers.update(HEADERS)


def _get_auth_token(instansi):
    """Get CSRF auth token from SPSE page."""
    url = f"{BASE_INAPROC}/{instansi}/lelang"
    r = _session.get(url, timeout=15)
    r.raise_for_status()

    # Try from cookies
    for cookie in _session.cookies:
        if 'SPSE_SESSION' in cookie.name:
            match = re.search(r'___AT=([A-Za-z0-9]+)', cookie.value)
            if match:
                return match.group(1)

    # Try from HTML
    match = re.search(r"authenticityToken\s*=\s*'([A-Za-z0-9]+)'", r.text)
    if match:
        return match.group(1)

    return ''


def get_lpse_list():
    """Get list of all LPSE instances."""
    try:
        r = _session.get(LPSE_LIST_URL, timeout=15)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and 'data' in data:
            return data['data']
        return []
    except Exception:
        # Return common ones as fallback
        return [
            {"repo_nama": "Kementerian PUPR", "instansi_code": "pu"},
            {"repo_nama": "Kementerian Keuangan", "instansi_code": "kemenkeu"},
            {"repo_nama": "LKPP", "instansi_code": "lkpp"},
        ]


def search_tender(instansi, keyword='', tahun='', start=0, length=20):
    """Search tender packages from an LPSE instance."""
    token = _get_auth_token(instansi)

    url = f"{BASE_INAPROC}/{instansi}/dt/lelang"
    payload = {
        'draw': 1,
        'start': start,
        'length': length,
        'search[value]': keyword,
        'search[regex]': 'false',
        'order[0][column]': 0,
        'order[0][dir]': 'desc',
        'authenticityToken': token,
        '_': int(time.time() * 1000),
    }
    if tahun:
        payload['tahun'] = tahun

    # Add required DataTables columns
    for i in range(5):
        payload[f'columns[{i}][data]'] = i
        payload[f'columns[{i}][name]'] = ''
        payload[f'columns[{i}][searchable]'] = 'true'
        payload[f'columns[{i}][orderable]'] = 'true' if i in [0,1,2,4] else 'false'

    r = _session.post(url, data=payload, timeout=30)
    r.raise_for_status()
    data = r.json()

    results = []
    for item in data.get('data', []):
        results.append(_parse_tender_row(item))

    return {
        'results': results,
        'total': data.get('recordsFiltered', len(results)),
        'instansi': instansi,
        'keyword': keyword,
    }


def search_non_tender(instansi, keyword='', tahun='', start=0, length=20):
    """Search non-tender (direct procurement) packages."""
    token = _get_auth_token(instansi)

    url = f"{BASE_INAPROC}/{instansi}/dt/pl"
    payload = {
        'draw': 1,
        'start': start,
        'length': length,
        'search[value]': keyword,
        'search[regex]': 'false',
        'order[0][column]': 0,
        'order[0][dir]': 'desc',
        'authenticityToken': token,
        '_': int(time.time() * 1000),
    }
    if tahun:
        payload['tahun'] = tahun

    for i in range(5):
        payload[f'columns[{i}][data]'] = i
        payload[f'columns[{i}][name]'] = ''
        payload[f'columns[{i}][searchable]'] = 'true'
        payload[f'columns[{i}][orderable]'] = 'true' if i in [0,1,2,4] else 'false'

    r = _session.post(url, data=payload, timeout=30)
    r.raise_for_status()
    data = r.json()

    results = []
    for item in data.get('data', []):
        results.append(_parse_tender_row(item))

    return {
        'results': results,
        'total': data.get('recordsFiltered', len(results)),
        'instansi': instansi,
        'keyword': keyword,
    }


def _parse_tender_row(item):
    """Parse a tender/non-tender row from DataTables response."""
    # item is typically a list [kode, nama_paket_html, instansi, hps, tahap]
    if isinstance(item, list):
        kode = _strip_html(str(item[0])) if len(item) > 0 else ''
        nama_html = str(item[1]) if len(item) > 1 else ''
        instansi_name = _strip_html(str(item[2])) if len(item) > 2 else ''
        hps = _strip_html(str(item[3])) if len(item) > 3 else ''
        tahap = _strip_html(str(item[4])) if len(item) > 4 else ''

        # Extract package name and ID from HTML
        nama = _strip_html(nama_html)
        id_match = re.search(r'lelang/(\d+)|nontender/(\d+)', nama_html)
        paket_id = (id_match.group(1) or id_match.group(2)) if id_match else ''

        return {
            'id': paket_id,
            'kode': kode,
            'nama_paket': nama,
            'instansi': instansi_name,
            'hps': hps,
            'tahap': tahap,
        }
    elif isinstance(item, dict):
        return {
            'id': str(item.get('id', '')),
            'kode': item.get('kode', ''),
            'nama_paket': _strip_html(item.get('nama_paket', '')),
            'instansi': item.get('instansi', ''),
            'hps': str(item.get('hps', '')),
            'tahap': item.get('tahap', ''),
        }
    return {}


def get_detail_tender(instansi, paket_id):
    """Get full detail of a tender package."""
    base = f"{BASE_INAPROC}/{instansi}"
    detail = {}

    # Pengumuman
    try:
        r = _session.get(f"{base}/lelang/{paket_id}/pengumumanlelang", timeout=15)
        if r.status_code == 200:
            detail['pengumuman'] = r.json()
    except Exception:
        pass

    # Peserta
    try:
        r = _session.get(f"{base}/lelang/{paket_id}/peserta", timeout=15)
        if r.status_code == 200:
            detail['peserta'] = r.json()
    except Exception:
        pass

    # Pemenang
    try:
        r = _session.get(f"{base}/evaluasi/{paket_id}/pemenang", timeout=15)
        if r.status_code == 200:
            detail['pemenang'] = r.json()
    except Exception:
        pass

    # Pemenang berkontrak
    try:
        r = _session.get(f"{base}/evaluasi/{paket_id}/pemenangberkontrak", timeout=15)
        if r.status_code == 200:
            detail['pemenang_berkontrak'] = r.json()
    except Exception:
        pass

    # Jadwal
    try:
        r = _session.get(f"{base}/lelang/{paket_id}/jadwal", timeout=15)
        if r.status_code == 200:
            detail['jadwal'] = r.json()
    except Exception:
        pass

    return detail


def get_detail_non_tender(instansi, paket_id):
    """Get full detail of a non-tender package."""
    base = f"{BASE_INAPROC}/{instansi}"
    detail = {}

    try:
        r = _session.get(f"{base}/nontender/{paket_id}/pengumumanpl", timeout=15)
        if r.status_code == 200:
            detail['pengumuman'] = r.json()
    except Exception:
        pass

    try:
        r = _session.get(f"{base}/nontender/{paket_id}/peserta", timeout=15)
        if r.status_code == 200:
            detail['peserta'] = r.json()
    except Exception:
        pass

    try:
        r = _session.get(f"{base}/evaluasinontender/{paket_id}/pemenang", timeout=15)
        if r.status_code == 200:
            detail['pemenang'] = r.json()
    except Exception:
        pass

    try:
        r = _session.get(f"{base}/nontender/{paket_id}/jadwal", timeout=15)
        if r.status_code == 200:
            detail['jadwal'] = r.json()
    except Exception:
        pass

    return detail


def _strip_html(text):
    """Remove HTML tags from text."""
    clean = re.sub(r'<[^>]+>', ' ', str(text))
    clean = re.sub(r'\s+', ' ', clean).strip()
    return clean


def close():
    _session.close()
